package com.mycompany.registration;

public class Login {
    String savedUsername;
    String savedPassword;
    String savedFirstName;
    String savedLastName;
    String savedCell;

    public boolean checkUserName(String username) {
        return username.contains("_") && username.length() <= 5;
    }

    public boolean checkPasswordComplexity(String password) {
        if (password.length() < 8) return false;
        boolean hasCapital = false;
        boolean hasNumber = false;
        boolean hasSpecial = false;
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) hasCapital = true;
            if (Character.isDigit(c)) hasNumber = true;
            if (!Character.isLetterOrDigit(c)) hasSpecial = true;
        }
        return hasCapital && hasNumber && hasSpecial;
    }

    public boolean checkCellPhoneNumber(String cell) {
        return cell.startsWith("+27") && cell.matches("\\+27\\d{9}");
    }

    public String registerUser(String username, String password, String cell, String firstName, String lastName) {
        if (!checkUserName(username)) {
            return "Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.";
        }
        if (!checkPasswordComplexity(password)) {
            return "Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.";
        }
        if (!checkCellPhoneNumber(cell)) {
            return "Cell phone number incorrectly formatted or does not contain international code.";
        }
        
        this.savedUsername = username;
        this.savedPassword = password;
        this.savedCell = cell;
        this.savedFirstName = firstName;
        this.savedLastName = lastName;
        
        return "User registered successfully.";
    }

    public boolean loginUser(String username, String password) {
        return username != null && username.equals(savedUsername) && password.equals(savedPassword);
    }

    public String returnLoginStatus(boolean loggedIn) {
        if (loggedIn) {
            return "Welcome " + savedFirstName + " " + savedLastName + " it is great to see you.";
        } else {
            return "Username or password incorrect, please try again.";
        }
    }
}