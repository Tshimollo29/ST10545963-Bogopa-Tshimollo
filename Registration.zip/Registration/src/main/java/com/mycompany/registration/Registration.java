package com.mycompany.registration;

import java.util.Scanner;

public class Registration {
    public static void main(String[] args) {
        Scanner input = new Scanner(System.in);
        Login login = new Login();

        System.out.print("Enter First Name: ");
        String firstName = input.nextLine();

        System.out.print("Enter Last Name: ");
        String lastName = input.nextLine();

        // USERNAME
        System.out.print("Enter Username: ");
        String username = input.nextLine();
        if (!login.checkUserName(username)) {
            System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than five characters in length.");
            return;
        } else {
            System.out.println("Username successfully captured.");
        }

        // PASSWORD
        System.out.print("Enter Password: ");
        String password = input.nextLine();
        if (!login.checkPasswordComplexity(password)) {
            System.out.println("Password is not correctly formatted, please ensure that the password contains at least eight characters, a capital letter, a number, and a special character.");
            return;
        } else {
            System.out.println("Password successfully captured.");
        }

        // CELL
        System.out.print("Enter Cell Number: ");
        String cell = input.nextLine();
        if (!login.checkCellPhoneNumber(cell)) {
            System.out.println("Cell phone number incorrectly formatted or does not contain international code.");
            return;
        } else {
            System.out.println("Cell number successfully captured.");
            
        }

        
        System.out.println(login.registerUser(username, password, cell, firstName, lastName));

       
        System.out.println("\n=== LOGIN ===");
        System.out.print("Enter Username: ");
        String loginUser = input.nextLine();
        System.out.print("Enter Password: ");
        String loginPass = input.nextLine();

        boolean isLoggedIn = login.loginUser(loginUser, loginPass);
        System.out.println(login.returnLoginStatus(isLoggedIn));
        
        input.close();
    }
}


